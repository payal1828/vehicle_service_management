from tkinter import*
from tkinter import messagebox
from PIL import Image,ImageTk 
import mysql.connector
import re
from customer import cust_win
import mysql.connector
from mechanic import mech_win
from serchcustom import cust_search
from searchmech import mech_search
from removecustom import cust_remove
from removemech import mech_remove
from allcustomer import all_cust
from allmechanic import all_mech
#loginform
class mylogin:
     def __init__(self,w):
          
          w.title("Login Window")
          w.geometry("800x600+350+100")
          w.configure(bg="#585858")
       
          frame1=Frame(w,bg="white")
          frame1.place(x=100,y=100,width=600,height=400)

          title=Label(frame1,text="LOGIN HERE",font=("times",22,"bold"),bg="black",fg="white")
          title.place(x=0,y=0,width=600)
          f_name=Label(frame1,text="Email_ID",font=("times",15,"bold"),bg="white",fg="#404040")
          f_name.place(x=210,y=100)
          a=StringVar()
          b=StringVar()
          txt_name=Entry(frame1,font=("times",15),bg="lightgray",textvariable=a)
          txt_name.place(x=210,y=130,width=230)
          password=Label(frame1,text="Password",font=("times",15,"bold"),bg="white",fg="#404040")
          password.place(x=210,y=190)
          txt_passw=Entry(frame1,font=("times",15),bg="lightgray",textvariable=b)
          txt_passw.place(x=210,y=220,width=230)
# function to check valid email
          def validate_email(txt_name):
            email_pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
            if re.match(email_pattern, txt_name):
              return True
            return False

          def fun():
           
           c=a.get()
           d=b.get()
          
           
           if c=="" or d=="":
             messagebox.showerror("error","please enter username and password")
           email = txt_name.get()
           if not validate_email(email):
                messagebox.showerror("Invalid Input", 
                             "Email must contain '@' and '.' characters.")
   
           else:
                     
                     mydb=mysql.connector.connect(
                     host="localhost",
                     user="root",
                     password="",
                     database="vehicle"
                 )
                     mycursor=mydb.cursor()
                     cmd=f"select a_username,a_password from login where a_username=%s and a_password=%s"
                     mycursor.execute(cmd,(c,d))
                     myresult=mycursor.fetchone()
                     mydb.commit()
                     if __name__ == "__main__":
                       if myresult:
                            w2=Tk()
                            obj2=mainform(w2)
                            w2.mainloop()
                            w.destroy()
                       else:
                                         messagebox.showerror("error","please enter valid username and password")

                            
                          
                     
        

          def regi():
           if btnlog.selection_get:
               register()
               w.destroy()

                   
          btnlog=Button(frame1,text="Register New Account?",command=regi,activebackground="black",activeforeground="white",cursor="hand2",width=18,font=("times",15,"bold"),fg="black",bg="white",bd=0)
          btnlog.place(x=210,y=260)
          btnlog2=Button(frame1,text="Login",command=fun,activebackground="white",activeforeground="black",width=15,font=("times",18,"bold"),bg="black",fg="white",cursor="hand2")
          btnlog2.place(x=210,y=330)

#registerform
def register():      
        w1=Tk()
        w1.title("Register Window")
        w1.geometry("800x600+350+100")
        w1.configure(bg="#585858")

        frame2=Frame(w1,bg="white")
        frame2.place(x=100,y=100,width=600,height=400)
        title=Label(frame2,text="REGISTER HERE",font=("times",22,"bold"),bg="black",fg="white")
        title.place(x=0,y=0,width=600)

        f_name=Label(frame2,text="Email_ID",font=("times",15,"bold"),bg="white",fg="#404040")
        f_name.place(x=210,y=100)
        a1=StringVar()
        b1=StringVar()
        txt_name1=Entry(frame2,font=("times",15),bg="lightgray",textvariable=a1)
        txt_name1.place(x=210,y=130,width=230)

        password=Label(frame2,text="Password",font=("times",15,"bold"),bg="white",fg="#404040")
        password.place(x=210,y=190)
        txt_passw1=Entry(frame2,font=("times",15),bg="lightgray",textvariable=b1)
        txt_passw1.place(x=210,y=220,width=230)
# function to check valid email
        def validate_email(txt_name1):
            email_pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
            if re.match(email_pattern, txt_name1):
              return True
            return False

        def registerdemo():
           u = txt_name1.get()
           p = txt_passw1.get()
           if u=="" or p=="":
                 messagebox.showerror("error","please enter username and password")
           email = txt_name1.get()
           if not validate_email(email):
                messagebox.showerror("Invalid Input", 
                             "Email must contain '@' and '.' characters.")
   
           else:
                 
                 mydb=mysql.connector.connect(
                     host="localhost",
                     user="root",
                     password="",
                     database="vehicle"
                 )
                 mycursor=mydb.cursor()
                 sqlinsert=f"insert into login values('','{txt_name1.get()}','{txt_passw1.get()}')"
                 mycursor.execute(sqlinsert)
                 myresult=mycursor.fetchone()
                 mydb.commit()
                 messagebox.showinfo("valid","success")
                 if __name__ == "__main__":
                    w3=Tk()
                    obj3=mainform(w3)
                    w3.mainloop()
                 w1.destroy()
                           
                 
                 
        btn1=Button(frame2,text="Create",command=registerdemo,activebackground="white",activeforeground="black",width=15,font=("times",18,"bold"),bg="black",fg="white",cursor="hand2")
        btn1.place(x=210,y=300)

class mainform:
     def __init__(self,w2):
       
      
       w2.title("Main window")
       w2.geometry("1520x790+0+0")
      # w2.configure(bg="#585858")

       title=Label(w2,text=" VEHICLE SERVICE MANAGEMENT SYSTEM",font=("times",22,"bold"),bg="lightgray")
       title.place(x=0,y=0,width=1520)
     # img1=Image.open(r"C:\Users\varun\OneDrive\Documents\payal\image\11.jpg")
     # photoimg1=ImageTk.PhotoImage(img1)
     # lablimg=Label(w2,image=photoimg1)
     # lablimg.place(x=0,y=40)

       frame1=Frame(w2,bg="lightgray",height=800)
       frame1.place(x=0,y=42,width=180)
       def addcustomer():
            new_window=Toplevel(w)
            app=cust_win(new_window)
       def addmech():
            new_window=Toplevel(w)
            app=mech_win(new_window)
       def customsearch():
            new_window=Toplevel(w)
            app=cust_search(new_window)
       def mechsearch():
            new_window=Toplevel(w)
            app=mech_search(new_window)
       def customremove():
            new_window=Toplevel(w)
            app=cust_remove(new_window)
       def mechremove():
            new_window=Toplevel(w)
            app=mech_remove(new_window)
       def customerall():
            new_window=Toplevel(w)
            app=all_cust(new_window)
       def mechall():
            new_window=Toplevel(w)
            app=all_mech(new_window)
                                                     
       btncus=Button(frame1,text="Add Customer",command=addcustomer,activebackground="white",activeforeground="black",width=14,font=("times",16,"bold"),bg="black",fg="white",cursor="hand2")
       btncus.place(x=0,y=80,height=32)
       btnsercus=Button(frame1,text="Update Customer",command=customsearch,activebackground="white",activeforeground="black",width=14,font=("times",16,"bold"),bg="black",fg="white",cursor="hand2")
       btnsercus.place(x=0,y=160,height=32)
       btndelcus=Button(frame1,text="Remove Customer",command=customremove,activebackground="white",activeforeground="black",width=14,font=("times",16,"bold"),bg="black",fg="white",cursor="hand2")
       btndelcus.place(x=0,y=240,height=32)
       btnallcus=Button(frame1,text="Show Customers",command=customerall,activebackground="white",activeforeground="black",width=14,font=("times",16,"bold"),bg="black",fg="white",cursor="hand2")
       btnallcus.place(x=0,y=320,height=32)

       btnmec=Button(frame1,text="Add Mechanic",command=addmech,activebackground="white",activeforeground="black",width=14,font=("times",16,"bold"),bg="black",fg="white",cursor="hand2")
       btnmec.place(x=0,y=400,height=32)
       btnsermec=Button(frame1,text="Search Mechanic",command=mechsearch,activebackground="white",activeforeground="black",width=14,font=("times",16,"bold"),bg="black",fg="white",cursor="hand2")
       btnsermec.place(x=0,y=480,height=32)
       btndelmec=Button(frame1,text="Remove Mechanic",command=mechremove,activebackground="white",activeforeground="black",width=14,font=("times",16,"bold"),bg="black",fg="white",cursor="hand2")
       btndelmec.place(x=0,y=560,height=32)
       btnallmec=Button(frame1,text="Show Mechanic",command=mechall,activebackground="white",activeforeground="black",width=14,font=("times",16,"bold"),bg="black",fg="white",cursor="hand2")
       btnallmec.place(x=0,y=640,height=32)
if __name__ == "__main__":
     w=Tk()
     obj=mylogin(w)
     w.mainloop()
