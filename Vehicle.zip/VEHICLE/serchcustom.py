from tkinter import*
from tkinter import messagebox
from PIL import Image,ImageTk
import mysql.connector
from tkinter import ttk
class cust_search:
     def __init__(self,w):
          
          w.title("Customer Window")
          w.geometry("1340x660+160+100")
          w.config(bg="#808080")
          title=Label(w,text="Update Customer Details",font=("times",22,"bold"),bg="white",fg="black")
          title.place(x=0,y=10,width=1350)

          nm=StringVar()
          b=StringVar()
          pn=StringVar()
          em=StringVar()
          da=StringVar()
          ty=StringVar()
          snm=StringVar()
          vn=StringVar()
          vmo=StringVar()
          sc=StringVar()
          f_name=Label(w,text="Full Name:",font=("times",15,"bold"))
          f_name.place(x=60,y=170)
          txt_name1=Entry(w,font=("times",15),bg="lightgray",textvariable=nm)
          txt_name1.place(x=190,y=170,width=220)

          gender=Label(w,text="Gender",font=("times",15,"bold"))
          gender.place(x=60,y=240)
          txt_gender=Entry(w,font=("times",15),bg="lightgray",textvariable=b)
          txt_gender.place(x=190,y=240,width=220)

          phone=Label(w,text="Phone_No:",font=("times",15,"bold"))
          phone.place(x=60,y=310)
          txt_phone=Entry(w,font=("times",15),bg="lightgray",textvariable=pn)
          txt_phone.place(x=190,y=310,width=220)

          email=Label(w,text="Email:",font=("times",15,"bold"))
          email.place(x=60,y=100)
          txt_email=Entry(w,font=("times",15),bg="lightgray",textvariable=em)
          txt_email.place(x=190,y=100,width=220)

          addr=Label(w,text="Address:",font=("times",15,"bold"))
          addr.place(x=60,y=380)
          txt_addr=Entry(w,font=("times",15),bg="lightgray")
          txt_addr.place(x=190,y=370,width=220,height=60)

          date=Label(w,text="Date:",font=("times",15,"bold"))
          date.place(x=60,y=470)
          txt_date=Entry(w,font=("times",15),bg="lightgray",textvariable=da)
          txt_date.place(x=190,y=470,width=220)

          s_name=Label(w,text="Service By:",font=("times",15,"bold"))
          s_name.place(x=60,y=540)
          txt_names=Entry(w,font=("times",15),bg="lightgray",textvariable=snm)
          txt_names.place(x=190,y=540,width=220)
         
          v_name=Label(w,text="Vehicle Name:",font=("times",15,"bold"))
          v_name.place(x=450,y=100)
          txt_namev=Entry(w,font=("times",15),bg="lightgray",textvariable=ty)
          txt_namev.place(x=610,y=100,width=220)

          vtype=Label(w,text="Vehicle Type:",font=("times",15,"bold"))
          vtype.place(x=450,y=170)
          txt_vtype=Entry(w,font=("times",15),bg="lightgray")
          txt_vtype.place(x=610,y=170,width=220)

          vnumber=Label(w,text="vehicle_No:",font=("times",15,"bold"))
          vnumber.place(x=450,y=240)
          txt_vnumber=Entry(w,font=("times",15),bg="lightgray",textvariable=vn)
          txt_vnumber.place(x=610,y=240,width=220)

          vmodel=Label(w,text="Vehicle Model:",font=("times",15,"bold"))
          vmodel.place(x=450,y=310)
          txt_vmodel=Entry(w,font=("times",15),bg="lightgray",textvariable=vmo)
          txt_vmodel.place(x=610,y=310,width=220)

          scharge=Label(w,text="Service Charge:",font=("times",15,"bold"))
          scharge.place(x=450,y=540)
          txt_scharge=Entry(w,font=("times",15),bg="lightgray",textvariable=sc)
          txt_scharge.place(x=610,y=540,width=220)

          problem=Label(w,text="Problem Description:",font=("times",15,"bold"))
          problem.place(x=450,y=380)
          txt_prob=Entry(w,font=("times",15),bg="lightgray")
          txt_prob.place(x=450,y=430,width=380,height=80)

          details_f=Frame(w,bd=2)
          details_f.place(x=880,y=100,width=450,height=500)
          scroll_x=ttk.Scrollbar(details_f,orient=HORIZONTAL)
          scroll_y=ttk.Scrollbar(details_f,orient=VERTICAL)
          cust_table=ttk.Treeview(details_f,columns=("c_id","c_name","c_gender","c_phone","c_email","c_address","v_type","v_name","v_number","v_brand","s_date","s_description","s_by","s_cost"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
          scroll_x.pack(side=BOTTOM,fill=X)
          scroll_y.pack(side=RIGHT,fill=Y)
          scroll_x.config(command=cust_table.xview)
          scroll_y.config(command=cust_table.yview)
          cust_table.heading("c_id",text="Customer_id")
          cust_table.heading("c_name",text="Customer_Name")
          cust_table.heading("c_gender",text="Customer_Gender")
          cust_table.heading("c_phone",text="Customer_phone_no")
          cust_table.heading("c_email",text="Customer_email")
          cust_table.heading("c_address",text="Customer_Address")
          cust_table.heading("v_type",text="vehicle_type")
          cust_table.heading("v_name",text="vehicle_Name")
          cust_table.heading("v_number",text="vehicle_Number")
          cust_table.heading("v_brand",text="vehicle_Brand")
          cust_table.heading("s_date",text="service_date")
          cust_table.heading("s_description",text="probelm")
          cust_table.heading("s_by",text="Sarvice_By")
          cust_table.heading("s_cost",text="Service_cost")

          cust_table["show"]="headings"

          cust_table.column("c_id",width=100)
          cust_table.column("c_name",width=100)
          cust_table.column("c_gender",width=100)
          cust_table.column("c_phone",width=100)
          cust_table.column("c_email",width=100)
          cust_table.column("c_address",width=100)
          cust_table.column("v_type",width=100)
          cust_table.column("v_name",width=100)
          cust_table.column("v_number",width=100)
          cust_table.column("v_brand",width=100)
          cust_table.column("s_date",width=100)
          cust_table.column("s_description",width=100)
          cust_table.column("s_by",width=100)
          cust_table.column("s_cost",width=100)

          cust_table.pack(fill=BOTH)
          cust_table.bind("<ButtonRelease-1>")      

         
          mydb=mysql.connector.connect(
                     host="localhost",
                     user="root",
                     password="",
                     database="vehicle"
                 )
          mycursor=mydb.cursor()
          mycursor.execute("select * from customer")
          myresult=mycursor.fetchall()
          if len(myresult)!=0:
                          
                          for i in myresult:
                                cust_table.insert("",END,values=i)
                                                    
                          mydb.commit()
                          mydb.close()
          def get_cursor(event=""):
                cursor_row=cust_table.focus()
                content=cust_table.item(cursor_row)
                row=content["values"]
               
                txt_name1.set(row[1])
                txt_gender.set(row[2])
                txt_phone.set(row[3])
                txt_email.set(row[4])
                txt_addr.set(row[5])
                txt_date.set(row[6])
                txt_names.set(row[7])
                txt_namev.set(row[8])
                txt_vtype.set(row[9])
                txt_vnumber.set(row[10])
                txt_vmodel.set(row[11])
                txt_prob.set(row[12])
                txt_scharge.set(row[13])

          def check():
               if nm.get()=="" or b.get()=="" or pn.get()=="" or em.get()=="" or da.get()=="" or snm.get()=="" or ty.get()=="" or vn.get()=="" or vmo.get()=="" or sc.get()=="" :
                    messagebox.showerror("error","Please valid infomation")
               else:
                    
                 mydb=mysql.connector.connect(
                     host="localhost",
                     user="root",
                     password="",
                     database="vehicle"
                 )
                 mycursor=mydb.cursor()
                 sql=f"update  customer set c_name='{txt_name1.get()}',c_gender='{txt_gender.get()}',c_phone={txt_phone.get()},c_address='{txt_addr.get()}',v_type='{txt_vtype.get()}',v_name='{txt_namev.get()}',v_number={txt_vnumber.get()},v_brand='{txt_vmodel.get()}',s_date={txt_date.get()},s_description='{txt_prob.get()}',s_by='{txt_names.get()}',s_cost={txt_scharge.get()} where c_email='{txt_email.get()}'"
                 
                
                 mycursor.execute(sql)            
                 mydb.commit()
                 messagebox.showinfo("valid","successfully added customer's data")
          
                       

          
          btn3=Button(w,text="Update",activebackground="white",command=check,activeforeground="black",width=15,font=("times",18,"bold"),bg="black",fg="white",cursor="hand2")
          btn3.place(x=150,y=600)
         
          btn2=Button(w,text="CLEAR",activebackground="white",activeforeground="black",width=15,font=("times",18,"bold"),bg="black",fg="white",cursor="hand2")
          btn2.place(x=550,y=600)


if __name__ == "__main__":
     w=Tk()
     obj=cust_search(w)
     w.mainloop()
