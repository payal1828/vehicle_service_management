from tkinter import*
from tkinter import messagebox
from PIL import Image,ImageTk
import mysql.connector
from tkinter import ttk
class all_cust:
     def __init__(self,w):
          
          w.title("Customer window")
          w.geometry("1000x660+230+100")
          w.config(bg="#808080")
          title=Label(w,text=" Show Customers Details",font=("times",22,"bold"),bg="white",fg="black")
          title.place(x=0,y=10,width=1000)
          details_f=Frame(w,bd=2)
          details_f.place(x=80,y=100,width=850,height=500)
          scroll_x=ttk.Scrollbar(details_f,orient=HORIZONTAL)
          scroll_y=ttk.Scrollbar(details_f,orient=VERTICAL)
          cust_table=ttk.Treeview(details_f,columns=("c_id","c_name","c_gender","c_phone","c_email","c_address","v_type","v_name","v_number","v_brand","s_date","s_description","s_by","s_cost"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
          scroll_x.pack(side=BOTTOM,fill=X)
          scroll_y.pack(side=RIGHT,fill=Y)
          scroll_x.config(command=cust_table.xview)
          scroll_y.config(command=cust_table.yview)
          cust_table.heading("c_id",text="Customer_id")
          cust_table.heading("c_name",text="Customer_Name")
          cust_table.heading("c_gender",text="Customer_Gender")
          cust_table.heading("c_phone",text="Customer_phone_no")
          cust_table.heading("c_email",text="Customer_email")
          cust_table.heading("c_address",text="Customer_Address")
          cust_table.heading("v_type",text="vehicle_type")
          cust_table.heading("v_name",text="vehicle_Name")
          cust_table.heading("v_number",text="vehicle_Number")
          cust_table.heading("v_brand",text="vehicle_Brand")
          cust_table.heading("s_date",text="service_date")
          cust_table.heading("s_description",text="probelm")
          cust_table.heading("s_by",text="Sarvice_By")
          cust_table.heading("s_cost",text="Service_cost")

          cust_table["show"]="headings"

          cust_table.column("c_id",width=100)
          cust_table.column("c_name",width=100)
          cust_table.column("c_gender",width=100)
          cust_table.column("c_phone",width=100)
          cust_table.column("c_email",width=100)
          cust_table.column("c_address",width=100)
          cust_table.column("v_type",width=100)
          cust_table.column("v_name",width=100)
          cust_table.column("v_number",width=100)
          cust_table.column("v_brand",width=100)
          cust_table.column("s_date",width=100)
          cust_table.column("s_description",width=100)
          cust_table.column("s_by",width=100)
          cust_table.column("s_cost",width=100)

          cust_table.pack(fill=BOTH)
                 

         
          mydb=mysql.connector.connect(
                     host="localhost",
                     user="root",
                     password="",
                     database="vehicle"
                 )
          mycursor=mydb.cursor()
          mycursor.execute("select * from customer")
          myresult=mycursor.fetchall()
          if len(myresult)!=0:
                          
                          for i in myresult:
                                cust_table.insert("",END,values=i)
                                                    
                          mydb.commit()
                          mydb.close()

if __name__ == "__main__":
     w=Tk()
     obj=all_cust(w)
     
     w.mainloop()
