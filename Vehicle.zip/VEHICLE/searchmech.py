from tkinter import*
from tkinter import messagebox
from PIL import Image,ImageTk
import mysql.connector

class mech_search:
     def __init__(self,w):
          
          w.title("Mechanic window")
          w.geometry("1000x560+250+140")
          w.config(bg="#808080")
          title=Label(w,text=" Search Mechanic Details",font=("times",22,"bold"),bg="white",fg="black")
          title.place(x=0,y=10,width=1000)

          nm=StringVar()
          b=StringVar()
          pn=StringVar()
          em=StringVar()
         
          jd=StringVar()
         
          sk=StringVar()
          sa=StringVar()
          
          f_name=Label(w,text="Full Name:",font=("times",15,"bold"))
          f_name.place(x=100,y=170)
          txt_name1=Entry(w,font=("times",15),bg="lightgray",textvariable=nm)
          txt_name1.place(x=210,y=170,width=220)

          gender=Label(w,text="Gender",font=("times",15,"bold"))
          gender.place(x=100,y=240)
          txt_gender=Entry(w,font=("times",15),bg="lightgray",textvariable=b)
          txt_gender.place(x=210,y=240,width=220)

        
          email=Label(w,text="Email:",font=("times",15,"bold"))
          email.place(x=100,y=100)
          txt_email=Entry(w,font=("times",15),bg="lightgray",textvariable=em)
          txt_email.place(x=210,y=100,width=220)

          addr=Label(w,text="Address:",font=("times",15,"bold"))
          addr.place(x=100,y=320)
          txt_addr=Entry(w,font=("times",15),bg="lightgray")
          txt_addr.place(x=210,y=310,width=220,height=60)

         
         
          phone=Label(w,text="Phone Number:",font=("times",15,"bold"))
          phone.place(x=550,y=100)
          txt_phone=Entry(w,font=("times",15),bg="lightgray",textvariable=pn)
          txt_phone.place(x=710,y=100,width=220)

          jdate=Label(w,text="Joining Date:",font=("times",15,"bold"))
          jdate.place(x=550,y=170)
          txt_jdate=Entry(w,font=("times",15),bg="lightgray",textvariable=jd)
          txt_jdate.place(x=710,y=170,width=220)

          skill=Label(w,text="Skill:",font=("times",15,"bold"))
          skill.place(x=550,y=240)
          txt_skill=Entry(w,font=("times",15),bg="lightgray",textvariable=sk)
          txt_skill.place(x=710,y=240,width=220)

          salary=Label(w,text="Salary:",font=("times",15,"bold"))
          salary.place(x=550,y=310)
          txt_salary=Entry(w,font=("times",15),bg="lightgray",textvariable=sa)
          txt_salary.place(x=710,y=310,width=220)
          def check():
               if nm.get()=="" or b.get()=="" or pn.get()=="" or em.get()==""  :
                    messagebox.showerror("error","Please valid infomation")
               else:
                    
                 mydb=mysql.connector.connect(
                     host="localhost",
                     user="root",
                     password="",
                     database="vehicle"
                 )
                 mycursor=mydb.cursor()
                 sql=f"update  mechanic set t_name='{txt_name1.get()}',t_gender='{txt_gender.get()}',t_phone={txt_phone.get()},t_date={txt_jdate.get()},t_address='{txt_addr.get()}',t_skills='{txt_skill.get()}',t_salary={txt_salary.get()} where t_email='{txt_email.get()}'"
                 
                
                 mycursor.execute(sql)            
                 mydb.commit()
                 messagebox.showinfo("valid","successfully updated Mechanic's data")
          
        
          
          btn3=Button(w,text="Update",activebackground="white",command=check,activeforeground="black",width=15,font=("times",18,"bold"),bg="black",fg="white",cursor="hand2")
          btn3.place(x=210,y=450)
         
          btn2=Button(w,text="Clear",activebackground="white",activeforeground="black",width=15,font=("times",18,"bold"),bg="black",fg="white",cursor="hand2")
          btn2.place(x=550,y=450)

if __name__ == "__main__":
     w=Tk()
     obj=mech_search(w)
     w.mainloop()
