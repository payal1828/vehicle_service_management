from tkinter import*
from tkinter import messagebox
from PIL import Image,ImageTk
import mysql.connector

class cust_remove:
     def __init__(self,w):
          
          w.title("Main window")
          w.geometry("800x560+380+100")
          w.config(bg="#808080")
          title=Label(w,text=" Remove Customer ",font=("times",22,"bold"),bg="white",fg="black")
          title.place(x=0,y=10,width=800)

        
          em=StringVar()
          

          email=Label(w,text="Email:",font=("times",15,"bold"))
          email.place(x=260,y=150)
          txt_email=Entry(w,font=("times",15),bg="lightgray",textvariable=em)
          txt_email.place(x=350,y=150,width=220)


          def check():
               if  em.get()==""  :
                    messagebox.showerror("error","Please valid infomation")
               else:
                    mydb=mysql.connector.connect(
                     host="localhost",
                     user="root",
                     password="",
                     database="vehicle"
                 )
                    mycursor=mydb.cursor()
                    sql="delete  from customer where c_email=%s"
                    value=(txt_email.get(),)
                    mycursor.execute(sql,value)
                    mydb.commit()
                    messagebox.showinfo("valid","successfully deleted customer's data")
      
          btn3=Button(w,text="Remove",activebackground="white",command=check,activeforeground="black",width=15,font=("times",18,"bold"),bg="black",fg="white",cursor="hand2")
          btn3.place(x=310,y=300)
          
if __name__ == "__main__":
     w=Tk()
     obj=cust_remove(w)
     w.mainloop()
