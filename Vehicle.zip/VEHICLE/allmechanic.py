from tkinter import*
from tkinter import messagebox
from PIL import Image,ImageTk
import mysql.connector
from tkinter import ttk
class all_mech:
     def __init__(self,w):
          
          w.title("Mechanic window")
          w.geometry("1000x560+250+140")
          w.config(bg="#808080")
          title=Label(w,text=" Show Mechanic Details",font=("times",22,"bold"),bg="white",fg="black")
          title.place(x=0,y=10,width=1000)
          details_f=Frame(w,bd=2)
          details_f.place(x=80,y=100,width=850,height=500)
          scroll_x=ttk.Scrollbar(details_f,orient=HORIZONTAL)
          scroll_y=ttk.Scrollbar(details_f,orient=VERTICAL)
          cust_table=ttk.Treeview(details_f,columns=("t_id","t_name","t_gender","t_phone","t_date","t_email","t_address","t_skills","t_salary"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
          scroll_x.pack(side=BOTTOM,fill=X)
          scroll_y.pack(side=RIGHT,fill=Y)
          scroll_x.config(command=cust_table.xview)
          scroll_y.config(command=cust_table.yview)
          cust_table.heading("t_id",text="Mechanic_id")
          cust_table.heading("t_name",text="Mechanic_Name")
          cust_table.heading("t_gender",text="Mechanic_Gender")
          cust_table.heading("t_phone",text="Mechanic_phone_no")
          cust_table.heading("t_date",text="Mechanic_Joinig_Date")

          cust_table.heading("t_email",text="Mechanic_email")
          cust_table.heading("t_address",text="Mechanic_Address")
          cust_table.heading("t_skills",text="Mechanic_skills")
          cust_table.heading("t_salary",text="Mechanic_Salary")
          
          cust_table["show"]="headings"

          cust_table.column("t_id",width=100)
          cust_table.column("t_name",width=100)
          cust_table.column("t_gender",width=120)
          cust_table.column("t_phone",width=120)
          cust_table.column("t_email",width=100)
          cust_table.column("t_date",width=130)

          cust_table.column("t_address",width=120)
          cust_table.column("t_skills",width=100)
          cust_table.column("t_salary",width=100)
        
          cust_table.pack(fill=BOTH)
                 

         
          mydb=mysql.connector.connect(
                     host="localhost",
                     user="root",
                     password="",
                     database="vehicle"
                 )
          mycursor=mydb.cursor()
          mycursor.execute("select * from mechanic")
          myresult=mycursor.fetchall()
          if len(myresult)!=0:
                          
                          for i in myresult:
                                cust_table.insert("",END,values=i)
                                                    
                          mydb.commit()
                          mydb.close()
if __name__ == "__main__":
     w=Tk()
     obj=all_mech(w)
     w.mainloop()
