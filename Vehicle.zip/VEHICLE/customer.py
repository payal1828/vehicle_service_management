from tkinter import*
from tkinter import messagebox
from PIL import Image,ImageTk
import mysql.connector
from tkinter import ttk
import re
class cust_win:
     def __init__(self,w):
          
          w.title("Customer window")
          w.geometry("1000x660+230+100")
          w.config(bg="#808080")
          title=Label(w,text=" Add Customer Details",font=("times",22,"bold"),bg="white",fg="black")
          title.place(x=0,y=10,width=1000)

          nm=StringVar()
          b=StringVar()
          pn=StringVar()
          em=StringVar()
          da=StringVar()
          ty=StringVar()
          snm=StringVar()
          vn=StringVar()
          vmo=StringVar()
          sc=StringVar()
          gender_var=StringVar()
          def validate_name(nm):
             if nm.isalpha():
               return True
             return False
# function to check valid phone number
          def validate_phone(txt_phone):
               if txt_phone.isdigit() and len(txt_phone) == 10:
                    return True
               return False
# function to check valid email
          def validate_email(em):
            email_pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
            if re.match(email_pattern, em):
              return True
            return False

       

          f_name=Label(w,text="Full Name:",font=("times",15,"bold"))
          f_name.place(x=110,y=100)
          txt_name1=Entry(w,font=("times",15),bg="lightgray",textvariable=nm)
          txt_name1.place(x=230,y=100,width=220)

          gender=Label(w,text="Gender",font=("times",15,"bold"))
          gender.place(x=110,y=170)
          radiomale=Entry(w,font=("times",15,"bold"),bg="lightgray")
          radiomale.place(x=230,y=170,width=220)
        
          phone=Label(w,text="Phone_No:",font=("times",15,"bold"))
          phone.place(x=110,y=240)
          txt_phone=Entry(w,font=("times",15),bg="lightgray",textvariable=pn)
          txt_phone.place(x=230,y=240,width=220)

          email=Label(w,text="Email:",font=("times",15,"bold"))
          email.place(x=110,y=310)
          txt_email=Entry(w,font=("times",15),bg="lightgray",textvariable=em)
          txt_email.place(x=230,y=310,width=220)

          addr=Label(w,text="Address:",font=("times",15,"bold"))
          addr.place(x=110,y=380)
          txt_addr=Entry(w,font=("times",15),bg="lightgray")
          txt_addr.place(x=230,y=370,width=220,height=60)

          date=Label(w,text="Date:",font=("times",15,"bold"))
          date.place(x=110,y=470)
          txt_date=Entry(w,font=("times",15),bg="lightgray",textvariable=da)
          txt_date.place(x=230,y=470,width=220)

          s_name=Label(w,text="Service By:",font=("times",15,"bold"))
          s_name.place(x=110,y=540)
          txt_names=Entry(w,font=("times",15),bg="lightgray",textvariable=snm)
          txt_names.place(x=230,y=540,width=220)
         
          v_name=Label(w,text="Vehicle Name:",font=("times",15,"bold"))
          v_name.place(x=550,y=100)
          txt_namev=Entry(w,font=("times",15),bg="lightgray",textvariable=ty)
          txt_namev.place(x=710,y=100,width=220)

          vtype=Label(w,text="Vehicle Type:",font=("times",15,"bold"))
          vtype.place(x=550,y=170)
          txt_vtype=Entry(w,font=("times",15),bg="lightgray")
          txt_vtype.place(x=710,y=170,width=220)

          vnumber=Label(w,text="vehicle_No:",font=("times",15,"bold"))
          vnumber.place(x=550,y=240)
          txt_vnumber=Entry(w,font=("times",15),bg="lightgray",textvariable=vn)
          txt_vnumber.place(x=710,y=240,width=220)

          vmodel=Label(w,text="Vehicle Model:",font=("times",15,"bold"))
          vmodel.place(x=550,y=310)
          txt_vmodel=Entry(w,font=("times",15),bg="lightgray",textvariable=vmo)
          txt_vmodel.place(x=710,y=310,width=220)

          scharge=Label(w,text="Service Charge:",font=("times",15,"bold"))
          scharge.place(x=550,y=540)
          txt_scharge=Entry(w,font=("times",15),bg="lightgray",textvariable=sc)
          txt_scharge.place(x=710,y=540,width=220)

          problem=Label(w,text="Problem Description:",font=("times",15,"bold"))
          problem.place(x=550,y=380)
          txt_prob=Entry(w,font=("times",15),bg="lightgray")
          txt_prob.place(x=550,y=430,width=350,height=80)

# function called when Submit is clicked
          def on_submit():
             if nm.get()==""  or pn.get()=="" or em.get()=="" or da.get()=="" or snm.get()=="" or ty.get()=="" or vn.get()=="" or vmo.get()=="" or sc.get()=="" :
              messagebox.showerror("error","Please valid infomation")
             name = nm.get()
             if not validate_name(name):
              messagebox.showerror("Invalid Input", 
                             "Name must contain only alphabets.")
             phone=txt_phone.get()
             if not validate_phone(phone):
                   messagebox.showerror("","Inavlid Phone Number,only 10 digit enter")
             email = em.get()
             if not validate_email(email):
                messagebox.showerror("Invalid Input", 
                             "Email must contain '@' and '.' characters.")
   
             if not re.match("^\\d+$",da.get()):
                   messagebox.showerror("","Inavlid date")
             if not re.match("^\\d+$",vn.get()):
                   messagebox.showerror("","Inavlid vehicle number")
             if not re.match("^\\d+$",sc.get()):
                   messagebox.showerror("","Inavlid service charge")
                                                                                                                                                                                                          
             else:
                

                 mydb=mysql.connector.connect(
                     host="localhost",
                     user="root",
                     password="",
                     database="vehicle"
                 )
                 mycursor=mydb.cursor()
                 sql=f"insert into customer (c_id,c_name,c_gender,c_phone,c_email,c_address,v_type,v_name,v_number,v_brand,s_date,s_description,s_by,s_cost) values('','{txt_name1.get()}','{radiomale.get()}',{txt_phone.get()},'{txt_email.get()}','{txt_addr.get()}','{txt_vtype.get()}','{txt_namev.get()}',{txt_vnumber.get()},'{txt_vmodel.get()}',{txt_date.get()},'{txt_prob.get()}','{txt_names.get()}',{txt_scharge.get()})"
                
                 mycursor.execute(sql)
                 mydb.commit()
                 messagebox.showinfo("valid","successfully added customer's data")
                 

         
          
          btn1=Button(w,text="ADD",activebackground="white",command=on_submit,activeforeground="black",width=15,font=("times",18,"bold"),bg="black",fg="white",cursor="hand2")
          btn1.place(x=250,y=600)
          btn2=Button(w,text="CLEAR",activebackground="white",activeforeground="black",width=15,font=("times",18,"bold"),bg="black",fg="white",cursor="hand2")
          btn2.place(x=550,y=600)
                
if __name__ == "__main__":
     w=Tk()
     obj=cust_win(w)
     w.mainloop()
